
export class ItemModel{
  constructor(
    public title:string,
    public pic:string,
    public price:number,
    public cate_id:string,
    public qty:number,
    public _id?:string,

  ){
  }
}
