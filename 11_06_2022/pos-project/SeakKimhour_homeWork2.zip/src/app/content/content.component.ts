import { Component, OnInit, Output } from '@angular/core';
import { Category } from '../model/category.model';
import { ItemService } from '../service/item.service';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss']
})
export class ContentComponent{

 First_group=''

}
